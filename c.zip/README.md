# Warning Jangan Disalah Gunakan
# Jangan Terlalu Brutal
# Jangan Dijual
# StaySafe
>> Author : MyZenix77,Dkmpostor,Eskey,Binz,ArnazXyz,Chacha.
>> Jika Ada Text "Undefined" Jangan Panik/Khawatir Itu Hanya Sebuah Teks Dan Tidak Memengaruhi Apapun Itu Hanya Sebuh Bug Coding
# Pake Dengan Aman Usahakan Jangan Terlalu Brutal 
Screenshot 
![deskripsi gambar](https://i.ibb.co/nk3BqRw/20220621-132505.jpg)
# Instalation
Download apk Termuxnya disini biar ngga eror🌟
[Klik Disini](https://f-droid.org/repo/com.termux_117.apk)👈
```bash
$ cd
$ pkg upgrade && pkg update 
$ pkg install nodejs
$ pkg install yarn
$ cd stumblezenix
$ yarn
$ node index
Cara Ambil Cookie
``` 
1. Download Http Injektor
[Klik Disini](https://www.google.com/amp/s/m.apkpure.com/id/httpcanary-%25E2%2580%2594-http-sniffer-capture-analysis/com.guoshi.httpcanary/amp)
2. Jalankan HTTPCANARY
Buka stumble guys.
3. Mainkan game sampai Anda mencapai top 1
4. Jika Anda Menang Jangan Klaim Hadiah
5. Pergi ke HTTPCANARY
Dan Klik Di Tautan https://hkitkabackend.eastus.cloudapp.azure.com:5010/round/finishv2/3
9. Permintaan Goto
10. Salin Nilai
11. Dan Pakai Termux Untuk Menjalankan Script
```
## Cara Update
```php
$ cd
$ cd stumblezenix
$ ls ( L kecil )
$ git pull
```
## KASIH BINTANG WOY🌟🌟🌟🌟🌟🌟🌟
![Typing SVG](https://readme-typing-svg.herokuapp.com?lines=Selamat+Bersenang-senang....!+)
